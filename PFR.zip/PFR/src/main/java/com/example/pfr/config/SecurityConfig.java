package com.example.pfr.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Конфигурация безопасности для приложения.
 * <p>
 * Этот класс настраивает правила доступа, аутентификации и шифрования паролей для приложения.
 */
@Configuration
public class SecurityConfig {

    /**
     * Настраивает фильтр безопасности для приложения.
     *
     * <ul>
     *     <li>Отключает CSRF-защиту для API.</li>
     *     <li>Определяет доступ к различным эндпоинтам:
     *         <ul>
     *             <li>Эндпоинты `/api/auth/**` доступны всем пользователям.</li>
     *             <li>Эндпоинты `/admin/**` доступны только пользователям с ролью ADMIN.</li>
     *             <li>Эндпоинты `/retiree/**` доступны только пользователям с ролью RETIREE.</li>
     *             <li>Эндпоинты `/pre-retiree/**` доступны только пользователям с ролью PRE_RETIREMENT.</li>
     *             <li>Все остальные запросы требуют аутентификации.</li>
     *         </ul>
     *     </li>
     *     <li>Настраивает форму входа:
     *         <ul>
     *             <li>URL для страницы входа — `/api/auth/index`.</li>
     *             <li>Обработка логина происходит через `/api/auth/login`.</li>
     *             <li>После успешного входа пользователь перенаправляется на `/api/dashboard`.</li>
     *         </ul>
     *     </li>
     *     <li>Настраивает выход:
     *         <ul>
     *             <li>URL для выхода — `/api/auth/logout`.</li>
     *             <li>После выхода пользователь перенаправляется на `/api/auth/login`.</li>
     *         </ul>
     *     </li>
     * </ul>
     *
     * @param http объект {@link HttpSecurity} для настройки правил безопасности
     * @return настроенный фильтр безопасности
     * @throws Exception если возникнут ошибки при настройке
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable) // Отключение CSRF для API
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**").permitAll() // Разрешить доступ к эндпоинтам регистрации и входа
                        .requestMatchers("/admin/**").hasRole("ADMIN") // Доступ только для администраторов
                        .requestMatchers("/retiree/**").hasRole("RETIREE") // Доступ только для пенсионеров
                        .requestMatchers("/pre-retiree/**").hasRole("PRE_RETIREMENT") // Доступ только для предпенсионеров
                        .anyRequest().authenticated() // Все остальные запросы требуют аутентификации
                )
                .formLogin(form -> form
                        .loginPage("/api/auth/index").permitAll() // URL для входа
                        .loginProcessingUrl("/api/auth/login")  // URL для обработки логина
                        .defaultSuccessUrl("/api/dashboard", true)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/api/auth/logout")
                        .logoutSuccessUrl("/api/auth/login").permitAll() // URL после выхода
                );

        return http.build();
    }

    /**
     * Определяет биновый компонент для шифрования паролей.
     * <p>
     * Использует {@link BCryptPasswordEncoder} для шифрования.
     *
     * @return объект {@link PasswordEncoder}, который шифрует пароли с использованием алгоритма BCrypt
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Создает {@link AuthenticationManager} для управления аутентификацией пользователей.
     *
     * @param configuration конфигурация аутентификации, предоставляемая Spring Security
     * @return объект {@link AuthenticationManager}
     * @throws Exception если возникнут ошибки при настройке
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }
}