package com.example.pfr.controller;

import com.example.pfr.entity.*;
import com.example.pfr.repository.InquiryRepository;
import com.example.pfr.repository.LawRepository;
import com.example.pfr.repository.PaymentRepository;
import com.example.pfr.repository.UserRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

/**
 * Контроллер для управления административными функциями системы.
 * Доступен только пользователям с ролью "ADMIN".
 */
@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserRepository userRepository;
    private final LawRepository lawRepository;
    private final PaymentRepository paymentRepository;
    private final InquiryRepository inquiryRepository;

    /**
     * Конструктор контроллера.
     *
     * @param userRepository     репозиторий пользователей
     * @param lawRepository      репозиторий законов
     * @param inquiryRepository  репозиторий обращений
     * @param paymentRepository  репозиторий выплат
     */
    public AdminController(UserRepository userRepository, LawRepository lawRepository, InquiryRepository inquiryRepository, PaymentRepository paymentRepository) {
        this.userRepository = userRepository;
        this.lawRepository = lawRepository;
        this.paymentRepository = paymentRepository;
        this.inquiryRepository = inquiryRepository;
    }

    /**
     * Отображает страницу со списком пользователей с фильтрацией по имени и роли.
     *
     * @param search  строка для поиска по имени пользователя
     * @param role    роль для фильтрации
     * @param model   объект модели для передачи данных в представление
     * @return имя представления для отображения списка пользователей
     */
    @GetMapping("/users")
    public String listUsers(
            @RequestParam(name = "search", required = false) String search,
            @RequestParam(name = "role", required = false) String role,
            Model model
    ) {
        List<User> users;
        if (search != null && !search.isEmpty() && role != null && !role.isEmpty()) {
            Role roleEnum = Role.valueOf(role.toUpperCase());
            users = userRepository.findByUsernameContainingIgnoreCaseAndRolesContaining(search, roleEnum);
        } else if (search != null && !search.isEmpty()) {
            users = userRepository.findByUsernameContainingIgnoreCase(search);
        } else if (role != null && !role.isEmpty()) {
            Role roleEnum = Role.valueOf(role.toUpperCase());
            users = userRepository.findByRolesContaining(roleEnum);
        } else {
            users = userRepository.findAll();
        }
        model.addAttribute("users", users);
        model.addAttribute("roles", Role.values());
        return "admin/users";
    }

    /**
     * Отображает страницу редактирования пользователя.
     *
     * @param id     идентификатор пользователя
     * @param model  объект модели для передачи данных в представление
     * @return имя представления для редактирования пользователя
     */
    @GetMapping("/users/edit/{id}")
    public String editUser(@PathVariable Long id, Model model) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            model.addAttribute("user", user);
            model.addAttribute("roles", Role.values());
            return "admin/edit-user";
        } else {
            return "redirect:/admin/users";
        }
    }

    /**
     * Обрабатывает обновление данных пользователя.
     *
     * @param id   идентификатор пользователя
     * @param user объект с обновлёнными данными пользователя
     * @return перенаправление на страницу списка пользователей
     */
    @PostMapping("/users/edit/{id}")
    public String updateUser(@PathVariable Long id, @ModelAttribute User user) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            User existingUser = userOpt.get();
            existingUser.setUsername(user.getUsername());
            existingUser.setPassword(user.getPassword());
            existingUser.setRoles(user.getRoles());
            existingUser.setFirstName(user.getFirstName());
            existingUser.setLastName(user.getLastName());
            existingUser.setEmail(user.getEmail());
            existingUser.setPhone(user.getPhone());
            existingUser.setDateOfBirth(user.getDateOfBirth());
            userRepository.save(existingUser);
        }
        return "redirect:/admin/users";
    }

    /**
     * Удаляет пользователя по идентификатору.
     *
     * @param id идентификатор пользователя
     * @return перенаправление на страницу списка пользователей
     */
    @PostMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/admin/users";
    }

    /**
     * Отображает страницу со списком законов с фильтрацией и сортировкой.
     *
     * @param search    строка для поиска по названию
     * @param sort      поле для сортировки
     * @param direction направление сортировки (asc/desc)
     * @param model     объект модели для передачи данных в представление
     * @return имя представления для отображения списка законов
     */
    @GetMapping("/admin-laws")
    public String listLaws(
            @RequestParam(name = "search", required = false) String search,
            @RequestParam(name = "sort", required = false, defaultValue = "title") String sort,
            @RequestParam(name = "direction", required = false, defaultValue = "asc") String direction,
            Model model
    ) {
        List<Law> laws;
        Sort sortOrder = direction.equalsIgnoreCase("desc") ?
                Sort.by(sort).descending() :
                Sort.by(sort).ascending();
        if (search != null && !search.isEmpty()) {
            laws = lawRepository.findByTitleContainingIgnoreCase(search, sortOrder);
        } else {
            laws = lawRepository.findAll(sortOrder);
        }
        model.addAttribute("laws", laws);
        model.addAttribute("search", search);
        model.addAttribute("sort", sort);
        model.addAttribute("direction", direction);
        return "admin/admin-laws";
    }

    /**
     * Отображает страницу добавления нового закона.
     *
     * @param model объект модели для передачи данных в представление
     * @return имя представления для добавления нового закона
     */
    @GetMapping("/admin-laws/add")
    public String showAddLawForm(Model model) {
        model.addAttribute("law", new Law());
        return "admin/add-law";
    }

    /**
     * Обрабатывает добавление нового закона.
     *
     * @param law объект закона для добавления
     * @return перенаправление на страницу со списком законов
     */
    @PostMapping("/admin-laws/add")
    public String addLaw(@ModelAttribute Law law) {
        lawRepository.save(law);
        return "redirect:/admin/admin-laws";
    }

    /**
     * Отображает страницу редактирования закона.
     *
     * @param id    идентификатор закона
     * @param model объект модели для передачи данных в представление
     * @return имя представления для редактирования закона
     */
    @GetMapping("/admin-laws/edit/{id}")
    public String editLaw(@PathVariable Long id, Model model) {
        Law law = lawRepository.findById(id).orElse(null);
        if (law != null) {
            model.addAttribute("law", law);
            return "admin/edit-law";
        } else {
            return "redirect:/admin/admin-laws";
        }
    }

    /**
     * Обрабатывает обновление данных закона.
     *
     * @param id  идентификатор закона
     * @param law объект закона с обновлёнными данными
     * @return перенаправление на страницу со списком законов
     */
    @PostMapping("/admin-laws/edit/{id}")
    public String updateLaw(@PathVariable Long id, @ModelAttribute Law law) {
        Law existingLaw = lawRepository.findById(id).orElse(null);
        if (existingLaw != null) {
            existingLaw.setTitle(law.getTitle());
            existingLaw.setContent(law.getContent());
            existingLaw.setPublicationDate(law.getPublicationDate());
            lawRepository.save(existingLaw);
        }
        return "redirect:/admin/admin-laws";
    }

    /**
     * Удаляет закон по идентификатору.
     *
     * @param id идентификатор закона
     * @return перенаправление на страницу со списком законов
     */
    @PostMapping("/admin-laws/delete/{id}")
    public String deleteLaw(@PathVariable Long id) {
        lawRepository.deleteById(id);
        return "redirect:/admin/admin-laws";
    }

    /**
     * Отображает страницу со списком выплат.
     *
     * @param model объект модели для передачи данных в представление
     * @return имя представления для отображения списка выплат
     */
    @GetMapping("/admin-payments")
    public String listPayments(Model model) {
        model.addAttribute("payments", paymentRepository.findAll());
        return "admin/admin-payments";
    }

    /**
     * Отображает страницу добавления новой выплаты.
     *
     * @param model объект модели для передачи данных в представление
     * @return имя представления для добавления выплаты
     */
    @GetMapping("/admin-payments/add")
    public String showAddPaymentForm(Model model) {
        model.addAttribute("payment", new Payment());
        model.addAttribute("users", userRepository.findAll());
        return "admin/add-payment";
    }

    /**
     * Обрабатывает добавление новой выплаты.
     *
     * @param payment объект выплаты для добавления
     * @return перенаправление на страницу со списком выплат
     */
    @PostMapping("/admin-payments/add")
    public String addPayment(@ModelAttribute Payment payment) {
        paymentRepository.save(payment);
        return "redirect:/admin/admin-payments";
    }

    /**
     * Отображает страницу редактирования выплаты.
     *
     * @param id    идентификатор выплаты
     * @param model объект модели для передачи данных в представление
     * @return имя представления для редактирования выплаты
     */
    @GetMapping("/admin-payments/edit/{id}")
    public String editPayment(@PathVariable Long id, Model model) {
        Payment payment = paymentRepository.findById(id).orElse(null);
        if (payment != null) {
            model.addAttribute("payment", payment);
            model.addAttribute("users", userRepository.findAll());
            return "admin/edit-payment";
        }
        return "redirect:/admin/admin-payments";
    }

    /**
     * Обрабатывает обновление данных выплаты.
     *
     * @param id      идентификатор выплаты
     * @param payment объект выплаты с обновлёнными данными
     * @return перенаправление на страницу со списком выплат
     */
    @PostMapping("/admin-payments/edit/{id}")
    public String updatePayment(@PathVariable Long id, @ModelAttribute Payment payment) {
        Payment existingPayment = paymentRepository.findById(id).orElse(null);
        if (existingPayment != null) {
            existingPayment.setAmount(payment.getAmount());
            existingPayment.setPaymentDate(payment.getPaymentDate());
            existingPayment.setPaymentNumber(payment.getPaymentNumber());
            existingPayment.setStatus(payment.getStatus());
            existingPayment.setUser(payment.getUser());
            paymentRepository.save(existingPayment);
        }
        return "redirect:/admin/admin-payments";
    }

    /**
     * Удаляет выплату по идентификатору.
     *
     * @param id идентификатор выплаты
     * @return перенаправление на страницу со списком выплат
     */
    @PostMapping("/admin-payments/delete/{id}")
    public String deletePayment(@PathVariable Long id) {
        paymentRepository.deleteById(id);
        return "redirect:/admin/admin-payments";
    }

    /**
     * Отображает список обращений с возможностью фильтрации по статусу.
     *
     * @param status статус для фильтрации
     * @param model  объект модели для передачи данных в представление
     * @return имя представления для отображения списка обращений
     */
    @GetMapping("/inquiries")
    public String listInquiries(@RequestParam(required = false) Inquiry.Status status, Model model) {
        List<Inquiry> inquiries = (status == null)
                ? inquiryRepository.findAll()
                : inquiryRepository.findByStatus(status);
        model.addAttribute("inquiries", inquiries);
        model.addAttribute("status", status);
        return "admin/inquiries";
    }

    /**
     * Обрабатывает разрешение обращения.
     *
     * @param inquiryId идентификатор обращения
     * @param response  ответ на обращение
     * @return перенаправление на страницу со списком обращений
     */
    @PostMapping("/inquiries/resolve")
    public String resolveInquiry(@RequestParam Long inquiryId, @RequestParam String response) {
        Inquiry inquiry = inquiryRepository.findById(inquiryId).orElseThrow();
        inquiry.setResponse(response);
        inquiry.setStatus(Inquiry.Status.RESOLVED);
        inquiryRepository.save(inquiry);
        return "redirect:/admin/inquiries";
    }
}