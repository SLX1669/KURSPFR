package com.example.pfr.controller;

import com.example.pfr.entity.Role;
import com.example.pfr.entity.User;
import com.example.pfr.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Map;

/**
 * Контроллер для обработки запросов аутентификации и регистрации пользователей.
 */
@Controller
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Конструктор для инициализации зависимостей.
     *
     * @param authenticationManager объект для управления аутентификацией
     * @param userRepository        репозиторий для работы с пользователями
     * @param passwordEncoder       объект для шифрования паролей
     */
    public AuthController(AuthenticationManager authenticationManager, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Отображает страницу входа.
     *
     * @return имя представления для страницы входа
     */
    @GetMapping("/index")
    public String loginPage() {
        return "index";
    }

    /**
     * Отображает форму регистрации.
     *
     * @return имя представления для страницы регистрации
     */
    @RequestMapping("/register")
    public String showRegistrationForm() {
        return "register";
    }

    /**
     * Обрабатывает регистрацию нового пользователя.
     *
     * @param username    имя пользователя (уникальное)
     * @param password    пароль пользователя
     * @param firstName   имя пользователя
     * @param lastName    фамилия пользователя
     * @param email       электронная почта
     * @param phone       номер телефона
     * @param dateOfBirth дата рождения
     * @param role        роль пользователя
     * @return перенаправление на страницу входа после успешной регистрации
     */
    @PostMapping("/register")
    public String registerUser(@RequestParam String username,
                               @RequestParam String password,
                               @RequestParam String firstName,
                               @RequestParam String lastName,
                               @RequestParam String email,
                               @RequestParam String phone,
                               @RequestParam String dateOfBirth,
                               @RequestParam String role) {

        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(passwordEncoder.encode(password));
        newUser.setFirstName(firstName);
        newUser.setLastName(lastName);
        newUser.setEmail(email);
        newUser.setPhone(phone);
        newUser.setDateOfBirth(LocalDate.parse(dateOfBirth));
        newUser.setRoles(Collections.singletonList(Role.valueOf(role)));
        userRepository.save(newUser);

        return "redirect:/api/auth/login";
    }

    /**
     * Обрабатывает вход пользователя.
     *
     * @param username имя пользователя
     * @param password пароль пользователя
     * @return перенаправление на страницу dashboard после успешного входа
     */
    @PostMapping("/login")
    public String loginUser(@RequestParam String username, @RequestParam String password) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        return "redirect:/api/dashboard";
    }

    /**
     * Проверяет, существует ли пользователь с указанным именем.
     *
     * @param username имя пользователя
     * @return JSON-ответ с результатом проверки
     */
    @GetMapping("/check-username")
    public ResponseEntity<Map<String, Boolean>> checkUsername(@RequestParam String username) {
        boolean exists = userRepository.existsByUsername(username);
        return ResponseEntity.ok(Collections.singletonMap("exists", exists));
    }

    /**
     * Проверяет, существует ли пользователь с указанным email.
     *
     * @param email электронная почта
     * @return JSON-ответ с результатом проверки
     */
    @GetMapping("/check-email")
    public ResponseEntity<Map<String, Boolean>> checkEmail(@RequestParam String email) {
        boolean exists = userRepository.existsByEmail(email);
        return ResponseEntity.ok(Collections.singletonMap("exists", exists));
    }

    /**
     * Проверяет, существует ли пользователь с указанным номером телефона.
     *
     * @param phone номер телефона
     * @return JSON-ответ с результатом проверки
     */
    @GetMapping("/check-phone")
    public ResponseEntity<Map<String, Boolean>> checkPhone(@RequestParam String phone) {
        boolean exists = userRepository.existsByPhone(phone);
        return ResponseEntity.ok(Collections.singletonMap("exists", exists));
    }
}