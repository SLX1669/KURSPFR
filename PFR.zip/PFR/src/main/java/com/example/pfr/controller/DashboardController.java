package com.example.pfr.controller;

import com.example.pfr.entity.Role;
import com.example.pfr.entity.User;
import com.example.pfr.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

/**
 * Контроллер для отображения главной страницы (dashboard) в зависимости от роли пользователя.
 */
@Controller
public class DashboardController {

    private final UserRepository userRepository;
    private static final Logger logger = LoggerFactory.getLogger(DashboardController.class);

    /**
     * Конструктор для инициализации зависимостей.
     *
     * @param userRepository репозиторий для работы с сущностями пользователей
     */
    public DashboardController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Отображает главную страницу (dashboard) для аутентифицированного пользователя.
     * В зависимости от роли пользователя перенаправляет на соответствующую страницу.
     *
     * @param model объект для передачи данных в представление
     * @return имя представления или перенаправление на соответствующую страницу
     */
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/api/dashboard")
    public String showDashboard(Model model) {
        // Получение текущего аутентифицированного пользователя
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();  // Получение имени пользователя из аутентификации

            logger.info("Current authenticated username: {}", username);
            logger.info("Current authenticated role: {}", authentication.getAuthorities());

            if (username == null || username.isEmpty()) {
                logger.error("Username is null or empty");
                return "redirect:/login";  // Перенаправление на страницу входа, если имя пустое
            }

            // Загрузка пользователя из базы данных
            User user = userRepository.findByUsername(username).orElse(null);

            if (user != null) {
                model.addAttribute("user", user);

                // Получение ролей пользователя
                List<Role> roles = user.getRoles();

                // Установка флагов для отображения элементов в зависимости от ролей
                boolean isAdmin = roles.contains(Role.ADMIN);
                boolean isRetiree = roles.contains(Role.RETIREE);
                boolean isPreRetiree = roles.contains(Role.PRE_RETIREMENT);

                model.addAttribute("admin", isAdmin);
                model.addAttribute("retire", isRetiree);
                model.addAttribute("preRetire", isPreRetiree);

                // Перенаправление на соответствующую страницу в зависимости от роли
                if (isAdmin) {
                    return "/admin/admin-dashboard";  // Страница для администраторов
                } else if (isRetiree) {
                    return "/retiree/retiree-dashboard";  // Страница для пенсионеров
                } else if (isPreRetiree) {
                    return "/pre-retiree/pre-retiree-dashboard";  // Страница для предпенсионеров
                } else {
                    return "redirect:/login";  // Перенаправление при отсутствии ролей
                }
            } else {
                logger.error("User not found for username: {}", username);  // Логирование ошибки
                return "redirect:/login";  // Перенаправление на страницу входа
            }
        }

        // Перенаправление на страницу входа, если пользователь не аутентифицирован
        return "redirect:/login";
    }
}