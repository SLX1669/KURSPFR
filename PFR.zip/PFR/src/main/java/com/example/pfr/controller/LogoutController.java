package com.example.pfr.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.ServletException;

/**
 * Контроллер для обработки выхода пользователя из системы.
 */
@Controller
public class LogoutController {

    /**
     * Завершает текущую сессию пользователя и выполняет выход из системы.
     *
     * @param request  объект {@link HttpServletRequest}, предоставляющий информацию о HTTP-запросе
     * @param response объект {@link HttpServletResponse}, предоставляющий управление HTTP-ответом
     * @return перенаправление на страницу входа
     */
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        // Получение текущей сессии, если она существует
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Уничтожение сессии
        }

        try {
            // Попытка выполнения выхода через механизм аутентификации
            request.logout();
        } catch (ServletException e) {
            e.printStackTrace(); // Логирование ошибки или обработка
        }

        // Перенаправление пользователя на страницу входа
        return "redirect:/index";
    }
}