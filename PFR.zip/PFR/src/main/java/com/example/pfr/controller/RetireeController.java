package com.example.pfr.controller;

import com.example.pfr.entity.Inquiry;
import com.example.pfr.entity.Law;
import com.example.pfr.entity.Payment;
import com.example.pfr.entity.User;
import com.example.pfr.repository.InquiryRepository;
import com.example.pfr.repository.LawRepository;
import com.example.pfr.repository.PaymentRepository;
import com.example.pfr.repository.UserRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Контроллер для обработки функционала пенсионеров.
 */
@Controller
@RequestMapping("/retiree")
public class RetireeController {

    private final PaymentRepository paymentRepository;
    private final InquiryRepository inquiryRepository;
    private final LawRepository lawRepository;
    private final UserRepository userRepository;

    /**
     * Конструктор для внедрения зависимостей.
     *
     * @param paymentRepository  репозиторий для работы с выплатами
     * @param lawRepository      репозиторий для работы с законами
     * @param userRepository     репозиторий для работы с пользователями
     * @param inquiryRepository  репозиторий для работы с обращениями
     */
    public RetireeController(PaymentRepository paymentRepository, LawRepository lawRepository, UserRepository userRepository, InquiryRepository inquiryRepository) {
        this.paymentRepository = paymentRepository;
        this.lawRepository = lawRepository;
        this.userRepository = userRepository;
        this.inquiryRepository = inquiryRepository;
    }

    /**
     * Просмотр списка обращений текущего пенсионера.
     *
     * @param model          объект {@link Model} для передачи данных в представление
     * @param authentication объект {@link Authentication}, содержащий данные текущего пользователя
     * @return имя представления для отображения обращений
     */
    @GetMapping("/inquiries")
    public String viewInquiries(Model model, Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            List<Inquiry> userInquiries = inquiryRepository.findByUserId(user.getId());
            model.addAttribute("inquiries", userInquiries);
        } else {
            model.addAttribute("error", "Пользователь не найден");
        }

        return "/retiree/inquiries";
    }

    /**
     * Переход на страницу создания нового обращения.
     *
     * @param authentication объект {@link Authentication}, содержащий данные текущего пользователя
     * @param model          объект {@link Model} для передачи данных в представление
     * @return имя представления для создания нового обращения
     */
    @GetMapping("/inquiries/new")
    public String createInquiryForm(Authentication authentication, Model model) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/api/auth/index";
        }

        String username = authentication.getName();
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            Inquiry inquiry = new Inquiry();
            inquiry.setUser(user);
            inquiry.setCreatedAt(LocalDate.now());
            model.addAttribute("inquiry", inquiry);
            model.addAttribute("user", user);
            return "/retiree/newinquiry";
        } else {
            return "redirect:/api/auth/index";
        }
    }

    /**
     * Создание нового обращения и сохранение его в базе данных.
     *
     * @param authentication объект {@link Authentication}, содержащий данные текущего пользователя
     * @param inquiry        объект {@link Inquiry}, содержащий данные нового обращения
     * @return перенаправление на страницу со списком обращений
     */
    @PostMapping("/inquiries/new")
    public String createInquiry(Authentication authentication, @ModelAttribute Inquiry inquiry) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/api/auth/index";
        }

        String username = authentication.getName();
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            inquiry.setUser(user);
            inquiry.setCreatedAt(LocalDate.now());
            inquiry.setStatus(Inquiry.Status.IN_PROGRESS);
            inquiryRepository.save(inquiry);
            return "redirect:/retiree/inquiries";
        } else {
            return "redirect:/api/auth/index";
        }
    }

    /**
     * Просмотр и фильтрация законов.
     *
     * @param search    строка поиска
     * @param sort      поле сортировки
     * @param direction направление сортировки ("asc" или "desc")
     * @param model     объект {@link Model} для передачи данных в представление
     * @return имя представления для отображения списка законов
     */
    @GetMapping("/laws")
    public String listLaws(
            @RequestParam(name = "search", required = false) String search,
            @RequestParam(name = "sort", required = false, defaultValue = "title") String sort,
            @RequestParam(name = "direction", required = false, defaultValue = "asc") String direction,
            Model model
    ) {
        List<Law> laws;
        Sort sortOrder = direction.equalsIgnoreCase("desc") ?
                Sort.by(sort).descending() :
                Sort.by(sort).ascending();

        if (search != null && !search.isEmpty()) {
            laws = lawRepository.findByTitleContainingIgnoreCase(search, sortOrder);
        } else {
            laws = lawRepository.findAll(sortOrder);
        }

        model.addAttribute("laws", laws);
        model.addAttribute("search", search);
        model.addAttribute("sort", sort);
        model.addAttribute("direction", direction);
        return "/retiree/laws";
    }

    /**
     * Просмотр списка выплат текущего пенсионера.
     *
     * @param model          объект {@link Model} для передачи данных в представление
     * @param authentication объект {@link Authentication}, содержащий данные текущего пользователя
     * @return имя представления для отображения списка выплат
     */
    @GetMapping("/payments")
    public String getUserPayments(Model model, Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            List<Payment> userPayments = paymentRepository.findByUserId(user.getId());
            model.addAttribute("payments", userPayments);
        } else {
            model.addAttribute("error", "Пользователь не найден");
        }

        return "/retiree/payments";
    }
}