package com.example.pfr.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import java.time.LocalDate;

/**
 * Сущность, представляющая запрос.
 */
@Entity
@Data
@ToString(exclude = "user")
public class Inquiry {

    /**
     * Уникальный идентификатор запроса.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Связь с пользователем (автором запроса).
     * <p>
     * Один запрос может быть связан только с одним пользователем.
     * </p>
     */
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /**
     * Содержание запроса.
     * <p>
     * Данное поле не может быть пустым.
     * </p>
     */
    @Lob
    @Column(nullable = false)
    private String content;

    /**
     * Ответ на запрос.
     * <p>
     * Это поле может быть пустым, если ответ ещё не был дан.
     * </p>
     */
    @Lob
    private String response;

    /**
     * Статус запроса.
     * <p>
     * Возможные значения: IN_PROGRESS (в процессе), RESOLVED (решён).
     * </p>
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    /**
     * Дата создания запроса.
     * <p>
     * Это поле устанавливается автоматически при создании запроса.
     * </p>
     */
    @Column(nullable = false, updatable = false)
    private LocalDate createdAt = LocalDate.now();

    /**
     * Перечисление возможных статусов запроса.
     */
    public enum Status {
        IN_PROGRESS, RESOLVED
    }
}