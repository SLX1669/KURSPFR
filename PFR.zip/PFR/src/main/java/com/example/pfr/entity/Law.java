package com.example.pfr.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

/**
 * Сущность, представляющая закон или нормативно-правовой акт.
 */
@Entity
@Data
public class Law {

    /**
     * Уникальный идентификатор закона.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Название закона.
     * <p>
     * Это поле не может быть пустым.
     * </p>
     */
    @Column(nullable = false)
    private String title;

    /**
     * Текст закона или нормативно-правового акта.
     * <p>
     * Это поле не может быть пустым.
     * </p>
     */
    @Lob
    @Column(nullable = false)
    private String content;

    /**
     * Дата публикации закона.
     * <p>
     * Это поле не может быть пустым.
     * </p>
     */
    @Column(nullable = false)
    private LocalDate publicationDate;
}