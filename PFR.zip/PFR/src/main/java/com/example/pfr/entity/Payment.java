package com.example.pfr.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Сущность, представляющая платёж пользователя.
 * <p>
 * Включает информацию о платеже, такую как дата, сумма, статус и уникальный номер платежа.
 * </p>
 */
@Entity
@Data
@Table(name = "payment")
@ToString(exclude = "user")
public class Payment {

    /**
     * Уникальный идентификатор платежа.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Связь с пользователем, который осуществил платёж.
     * <p>
     * Это поле обязательно для заполнения.
     * </p>
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /**
     * Дата совершения платежа.
     * <p>
     * Это поле не может быть пустым.
     * </p>
     * Дата указывается в формате "yyyy-MM-dd".
     */
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date paymentDate;

    /**
     * Сумма платежа.
     * <p>
     * Это поле не может быть пустым. Сумма представлена с точностью до 38 знаков и 2 десятичных знаков.
     * </p>
     */
    @Column(name = "amount", precision = 38, scale = 2, nullable = false)
    private BigDecimal amount;

    /**
     * Статус платежа.
     * <p>
     * Возможные значения: {@link Status#EXECUTED} или {@link Status#PENDING}.
     * </p>
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private Status status;

    /**
     * Уникальный номер платежа.
     * <p>
     * Это поле обязательно для заполнения.
     * </p>
     */
    @Column(name = "payment_number", nullable = false)
    private String paymentNumber;

    /**
     * Перечисление статусов платежа.
     */
    public enum Status {
        /**
         * Платёж был выполнен.
         */
        EXECUTED,

        /**
         * Платёж в ожидании.
         */
        PENDING
    }
}