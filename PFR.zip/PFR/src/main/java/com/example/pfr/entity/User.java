package com.example.pfr.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import java.time.LocalDate;
import java.util.List;


/**
 * Сущность пользователя системы.
 * <p>
 * Представляет информацию о пользователе, включая его личные данные, роли и связи с другими сущностями, такими как платежи и запросы.
 * </p>
 */
@Entity
@Table(name = "user")
@Data
@ToString(exclude = {"payments", "inquiries"})
public class User {

    /**
     * Идентификатор пользователя.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Уникальное имя пользователя.
     */
    @Column(unique = true, nullable = false)
    private String username;

    /**
     * Пароль пользователя.
     */
    private String password;

    /**
     * Список ролей пользователя.
     * Роли сохраняются как строки в связанной таблице {@code user_roles}.
     */
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
            name = "user_roles", // Таблица-связка
            joinColumns = @JoinColumn(name = "user_id")
    )
    @Enumerated(EnumType.STRING) // Храним роли как строки
    @Column(name = "roles")
    private List<Role> roles;

    /**
     * Уникальный адрес электронной почты пользователя.
     */
    @Column(unique = true, nullable = false)
    private String email;

    /**
     * Уникальный номер телефона пользователя.
     */
    @Column(unique = true, nullable = false)
    private String phone;

    /**
     * Имя пользователя.
     */
    private String firstName;

    /**
     * Фамилия пользователя.
     */
    private String lastName;

    /**
     * Дата рождения пользователя.
     */
    @Column(nullable = false)
    private LocalDate dateOfBirth;

    /**
     * Список платежей пользователя.
     * Связь с сущностью {@link Payment}.
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<Payment> payments;

    /**
     * Список запросов пользователя.
     * Связь с сущностью {@link Inquiry}.
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<Inquiry> inquiries;
}