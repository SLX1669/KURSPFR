package com.example.pfr.repository;

import com.example.pfr.entity.Inquiry;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Репозиторий для работы с сущностью {@link Inquiry}.
 * <p>
 * Предоставляет методы для работы с базой данных, включая получение всех обращений пользователя
 * и фильтрацию обращений по статусу.
 * </p>
 */
public interface InquiryRepository extends JpaRepository<Inquiry, Long> {

    /**
     * Получить все обращения пользователя по его идентификатору.
     *
     * @param userId Идентификатор пользователя.
     * @return Список всех обращений пользователя.
     */
    List<Inquiry> findByUserId(Long userId);

    /**
     * Получить все обращения с заданным статусом.
     *
     * @param status Статус обращений.
     * @return Список всех обращений с данным статусом.
     */
    List<Inquiry> findByStatus(Inquiry.Status status);
}