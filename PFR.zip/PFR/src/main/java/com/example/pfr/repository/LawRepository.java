package com.example.pfr.repository;

import com.example.pfr.entity.Law;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Репозиторий для работы с сущностью {@link Law}.
 * <p>
 * Предоставляет метод для поиска законов по названию с учетом регистра и сортировкой.
 * </p>
 */
@Repository
public interface LawRepository extends JpaRepository<Law, Long> {

    /**
     * Поиск законов по части названия с учетом регистра и сортировкой.
     *
     * @param search Часть названия закона для поиска.
     * @param sort Параметры сортировки.
     * @return Список законов, название которых содержит переданную строку (не учитывая регистр), отсортированный согласно переданным параметрам.
     */
    List<Law> findByTitleContainingIgnoreCase(String search, Sort sort);
}