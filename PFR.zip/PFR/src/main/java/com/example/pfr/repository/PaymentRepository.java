package com.example.pfr.repository;

import com.example.pfr.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Репозиторий для работы с сущностью {@link Payment}.
 * <p>
 * Предоставляет метод для поиска выплат по ID пользователя.
 * </p>
 */
@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    /**
     * Получить все выплаты пользователя по его ID.
     *
     * @param userId ID пользователя, для которого нужно найти выплаты.
     * @return Список выплат, принадлежащих пользователю с заданным ID.
     */
    List<Payment> findByUserId(long userId);
}