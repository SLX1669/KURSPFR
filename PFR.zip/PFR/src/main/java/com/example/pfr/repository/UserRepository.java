package com.example.pfr.repository;

import com.example.pfr.entity.Role;
import com.example.pfr.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Репозиторий для работы с сущностью {@link User}.
 * <p>
 * Предоставляет методы для поиска пользователей по различным критериям, включая имя пользователя, роль,
 * а также проверки существования пользователей по имени, email и номеру телефона.
 * </p>
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Найти пользователя по имени пользователя.
     *
     * @param username Имя пользователя.
     * @return Опциональный объект {@link User}, который может быть пустым, если пользователь не найден.
     */
    Optional<User> findByUsername(String username);

    /**
     * Найти пользователей, чье имя содержит заданную строку (независимо от регистра).
     *
     * @param username Часть имени пользователя.
     * @return Список пользователей, чьи имена содержат заданную строку.
     */
    List<User> findByUsernameContainingIgnoreCase(String username);

    /**
     * Найти пользователей по роли.
     *
     * @param role Роль пользователя.
     * @return Список пользователей, обладающих заданной ролью.
     */
    List<User> findByRolesContaining(Role role);

    /**
     * Найти пользователей по части имени и роли.
     *
     * @param username Часть имени пользователя.
     * @param role Роль пользователя.
     * @return Список пользователей, чье имя содержит заданную строку и которые обладают заданной ролью.
     */
    List<User> findByUsernameContainingIgnoreCaseAndRolesContaining(String username, Role role);

    /**
     * Проверить, существует ли пользователь с таким именем пользователя.
     *
     * @param username Имя пользователя.
     * @return {@code true}, если пользователь с таким именем существует, иначе {@code false}.
     */
    boolean existsByUsername(String username);

    /**
     * Проверить, существует ли пользователь с таким email.
     *
     * @param email Адрес электронной почты.
     * @return {@code true}, если пользователь с таким email существует, иначе {@code false}.
     */
    boolean existsByEmail(String email);

    /**
     * Проверить, существует ли пользователь с таким номером телефона.
     *
     * @param phone Номер телефона.
     * @return {@code true}, если пользователь с таким номером телефона существует, иначе {@code false}.
     */
    boolean existsByPhone(String phone);
}