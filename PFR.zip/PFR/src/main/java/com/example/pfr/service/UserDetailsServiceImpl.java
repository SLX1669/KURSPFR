package com.example.pfr.service;

import com.example.pfr.entity.User;
import com.example.pfr.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Реализация {@link UserDetailsService} для загрузки информации о пользователе для аутентификации и авторизации.
 * <p>
 * Этот сервис извлекает данные пользователя из репозитория {@link UserRepository} по имени пользователя
 * и преобразует их в объект {@link UserDetails}, который используется Spring Security для управления доступом.
 * </p>
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * Конструктор для инжекции зависимости {@link UserRepository}.
     *
     * @param userRepository Репозиторий для работы с пользователями.
     */
    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Загружает информацию о пользователе по имени пользователя для аутентификации.
     * <p>
     * Если пользователь не найден, выбрасывается {@link UsernameNotFoundException}.
     * </p>
     *
     * @param username Имя пользователя для аутентификации.
     * @return {@link UserDetails} объект с данными пользователя, включая роли.
     * @throws UsernameNotFoundException Если пользователь не найден.
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Получаем пользователя по имени
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        // Логирование ролей для отладки
        System.out.println("User roles: " + user.getRoles());

        // Преобразуем роли пользователя в список SimpleGrantedAuthority
        List<SimpleGrantedAuthority> authorities = user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.name()))  // Преобразуем роль в формат "ROLE_..."
                .collect(Collectors.toList());

        // Возвращаем пользователя в формате UserDetails для использования Spring Security
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), authorities);
    }
}